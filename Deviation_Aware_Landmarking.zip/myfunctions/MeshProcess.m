function [vertex,faces] = MeshProcess(vertex,faces)
%% Remove invalid border faces and ears, useful for registration.
% input should be N*3

if size(vertex,2) > size(vertex,1)
    vertex = vertex';
end

if size(faces,2) > size(faces,1)
    faces = faces';
end

% % remove nonmanifold vertices and fill in the holes 
% 
% [vertex,faces] = remove_non_manifold_vertices(vertex,faces);
% boundaries = detect_mesh_holes_and_boundary(faces);
% faces = fill_mesh_holes(vertex,faces,boundaries,'opened',200);

[vertex,faces] = removeInvalidBorderFaces(vertex,faces);
[vertex,faces]= removeMeshEars(vertex,faces);
[vertex,faces]= trimMesh(vertex,faces);
end
