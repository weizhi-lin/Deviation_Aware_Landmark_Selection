function M = SegmentLandmarks(M,Nlmk)
N = size(M.Seg.V_seg,2);
% retrieve center index on each segment
CindS = []; 
for j = 1:N
    [~,index]=ismember(M.Whole.V(M.Whole.Center,:),M.Seg.V_seg{j},'rows');
    CindS(j) = index(index~=0);
end
    
tlmkS = tic;

lmk = SegGPlmk(M.Seg.V_seg, M.Seg.F_seg, M.Seg.Center, Nlmk,'Area');

Ind = {};
for j = 1:N
    [~,index]=ismember(M.Seg.V_seg{j}(lmk{j},:),M.Whole.V,'rows');
    Ind{j} = index;
end
lmk_all = cell2mat(Ind'); 

M.Whole.lmk_all = lmk_all; 
M.Seg.lmk = lmk;

end