function [J,D] = GenerateVoronoiDiagram(vertex,faces,landmarks,path)
% % inpute vertex should be 3*N
% if size(vertex,2)<size(vertex,1)
%     vertex = vertex';
% end
% if size(faces,2)<size(faces,1)
%     faces = faces';
% end

m = max(size(landmarks));

compile_mex
[D,Z,Q] = perform_fast_marching_mesh(vertex, faces, landmarks);
[B,I,J] = unique(Q);
v = randperm(m)'; % without repeating elements
J = v(J);

if(~isdeployed)
  cd(path);
end
% 
% figure()
% options.face_vertex_color = D;
% plot_mesh(vertex,faces, options); hold on
% colormap jet(256);
% h = plot3(vertex(landmarks,1), vertex(landmarks,2), vertex(landmarks,3), 'k.');
% set(h, 'MarkerSize', 35);
end