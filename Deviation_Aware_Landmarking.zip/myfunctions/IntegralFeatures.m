function [Cgauss,Cmean,fcom,dmin] = IntegralFeatures(vertex,faces,r,omega)
M = Mesh('VF',vertex',faces');
area = meshFaceAreas(M.V',M.F');
M.Normalize();
[~,~,flip] = M.ComputeNormal();
if flip
    M.F = M.F([1 3 2],:);
end
AreaDistortions = AreaDistortionFeature(M,0.1);
fcom = AreaDistortions';
 [Cgauss,Cmean,~,~,~,Cmax]  = M.ComputeCurvature();

omega2 = omega * omega;
dmin = r./sqrt(1+omega2.*Cmax.^2);

end 