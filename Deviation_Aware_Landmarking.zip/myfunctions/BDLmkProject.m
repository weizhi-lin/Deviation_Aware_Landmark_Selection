% project the 4 apexes 
function lmkb2 = BDLmkProject(vertex1,lmkb, vertex2, faces2)
% boundary = meshBoundaryVertexIndices(vertex2,faces2);
boundary = compute_boundary(faces2);
boundary_v = vertex2(boundary,:);
Ind_vertex = vertex1(lmkb,:);
lmkb2 = [];

for i =1:4
    t = dsearchn(boundary_v,Ind_vertex(i,:));
    b = find(ismember(vertex2,boundary_v(t,:),'rows'));
    lmkb2 = [lmkb2;b];
end
end