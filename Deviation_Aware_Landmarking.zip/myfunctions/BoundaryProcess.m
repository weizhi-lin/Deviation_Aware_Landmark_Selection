function [vertexn,facesn] = BoundaryProcess(vertex,faces,lenm)
% remove the irregular edges of reconstructed segments 

edges = meshEdges(vertex, faces); % edge vertex indices from face array.
edgeFaces = trimeshEdgeFaces(vertex,faces); % edge connected faces indices 
lengths = meshEdgeLength(vertex, edges, faces);
eI = find(lengths>lenm);
face_to_delete = nonzeros(unique(edgeFaces(eI,:)));
disp(['number of deleted faces = ',num2str(size(face_to_delete,1))]);
if eI > 0
    [vertex,faces]= removeMeshFaces(vertex,faces,face_to_delete);
end
[vertexn,facesn] = removeInvalidBorderFaces(vertex,faces);
[vertexn,facesn] = removeMeshEars(vertexn,facesn);
[vertexn,facesn] = trimMesh(vertexn,facesn);

end


% figure()
% plot_mesh(vertexn,facesn);shading faceted; 