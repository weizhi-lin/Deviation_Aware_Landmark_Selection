function [Lambda,Cgauss,Cmean,Ctotal] = ComputeWeightFunction(vertex,faces)
% Compute attribute at each vertex

G = Mesh('VF',vertex',faces');
G.Centralize('ScaleArea');
[~,TriArea] = G.ComputeSurfaceArea();
G.Aux.VertArea = G.F2V'*TriArea;

% lambda = 0.8;
% Lambda = G.Aux.VertArea.*(lambda*abs(Cgauss)/sum(abs(Cgauss))+(1-lambda)*abs(Cmean)/sum(abs(Cmean)));
% [Cgauss,Cmean] = G.ComputeCurvature();
[Cgauss,Cmean,~,~,Cmin,Cmax,~] = G.ComputeCurvature();
Ctotal = abs(Cmin)+abs(Cmax);
[~,curvature] = findPointNormals(G.V',10);
Lambda = G.Aux.VertArea.*curvature/sum(curvature);
end 

% figure()
% subplot(1,4,1)
% options.face_vertex_color = perform_saturation(Cgauss,1.5);
% plot_mesh(vertex1,faces1, options); 
% colormap jet(256);
% title('Gaussian Curvature');
% subplot(1,4,2)
% options.face_vertex_color = perform_saturation(Cmean,1.5);
% plot_mesh(vertex1,faces1, options); 
% colormap jet(256);
% title('Mean Curvature');
% subplot(1,4,3)
% options.face_vertex_color = perform_saturation(Ctotal,1.5);
% plot_mesh(vertex1,faces1, options); 
% colormap jet(256);
% title('Total Curvature');
% subplot(1,4,4)
% options.face_vertex_color = perform_saturation(Lambda,1.5);
% plot_mesh(vertex1,faces1, options); 
% colormap jet(256);
% title('Lambda (Weighted Curvature)');