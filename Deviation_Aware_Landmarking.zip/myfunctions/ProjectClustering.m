%% Project the labeling in mesh1(vertex1) to mesh2(vetex2)

function label2 = ProjectClustering(vertex1, vertex2, label)

% check the dimensionality

if size(vertex1,2)>size(vertex1,1)
    vertex1 = vertex1';
end
if size(vertex2,2)>size(vertex2,1)
    vertex2 = vertex2';
end

% find the nearest vertices in vertex2

[~,idx_test] = pdist2(vertex1,vertex2,'euclidean','Smallest',1);
idx = idx_test';
idx1 = zeros(length(idx),1);

for i =1:length(idx)
    k = idx(i,1);
    idx1(i)=label(k);
end

label2 = idx1;
end