function  [rho,delta,dc,p] = FindBestDesicionValue(DS)
% N = size(DS,1);
p_up = 0.003;
p_low = 0.0015;
P = p_low:0.00001:p_up;%0.00002
VarD = [];
% Dc = [];
% R = [];
% Delta = [];
i = 1;
for p = P
    [~,delta,dc] = DecisionValue(DS,p);
%     if dc<1e-5
%         break
%     end
    delta1=mapminmax(delta', 0, 1);
%     rho1=mapminmax(rho', 0, 1)';
%     NormD(i) = norm(delta1);
    VarD(i) = var(delta1);
%     VarR(i) = var(rho1);
    Dc(i) = dc;
%     R(i) = mean(rho);
%     Delta(i) = mean(delta);
    i = i+1;
end

% % min_d = min(DS(DS>0));
[~,b] = max(VarD(Dc>0));
p = P(b);
[rho,delta,dc] = DecisionValue(DS,p);

end

% figure();scatter(rho,delta);
% rho1=mapminmax(rho', 0, 1)';
% delta1=mapminmax(delta', 0, 1)';
% figure();scatter(Dc,VarD);title('VarD');
% figure();scatter(P,VarD);title('VarD');