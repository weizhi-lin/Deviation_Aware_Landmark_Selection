% Feature sensitive remeshing

function [vertexV,facesV] = FeatureRemesh(vertex,faces,remeshN,filter,path)

% inpute vertex should be 3*N
if size(vertex,2)<size(vertex,1)
    vertex = vertex';
end
if size(faces,2)<size(faces,1)
    faces = faces';
end

n = size(vertex,2);
m = remeshN;
W = rescale(filter, .001, 1);
options.W = W;

% options.face_vertex_color = perform_saturation(C,1.5);
% plot_mesh(vertex,faces, options);
% colormap jet(256);

landmarks = 1;

compile_mex

[D,~,~] = perform_fast_marching_mesh(vertex, faces, landmarks);


for i=2:m
    % select
    [~,landmarks(end+1)] = max(D);
    % update
    options.constraint_map = D;
    [D1,~,~] = perform_fast_marching_mesh(vertex, faces, landmarks,options);
    D = min(D,D1);
end

[~,~,Q] = perform_fast_marching_mesh(vertex, faces, landmarks);
% compute the mesh
V = Q(faces); V = sort(V,1);
V = unique(V', 'rows')';
d = 1 + (V(1,:)~=V(2,:)) + (V(2,:)~=V(3,:));
I = find(d==3); I = sort(I);

z = zeros(n,1);

z(landmarks) = (1:length(landmarks))';
facesV = z(V(:,I));
vertexV = vertex(:,landmarks);
% Re-orient the faces so that they point outward of the mesh.
options.method = 'slow';
options.verb = 0;
facesV = perform_faces_reorientation(vertexV,facesV, options);

if(~isdeployed)
  cd(path);
end

end