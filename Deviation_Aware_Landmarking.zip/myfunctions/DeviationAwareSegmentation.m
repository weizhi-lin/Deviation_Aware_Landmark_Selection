function M = DeviationAwareSegmentation(Data,para,var)
%% Construct deviation-aware 
% Data: input Mesh data type
% para.currentFolder: working space
% para.remeshN: number of remeshed vertices 
% var: control the type of feature fliter


currentFolder = para.currentFolder;

%% Step1: Input mesh and preprosessing
vertex1 = Data.V';
faces1 = Data.F';
[vertex1,faces1] = trimMesh(vertex1,faces1);

Nvertex = size(vertex1,1);
if Nvertex < 1e+5
    remeshN = para.remeshN;
else
    remeshN = Nvertex *0.03;
    remeshN = min(remeshN,5000);
end

%% Step2: Feature sensitive remeshing
[~,~,flip] = Data.ComputeNormal();
if flip
    Data.F = Data.F([1 3 2],:);
end
[Cgauss,~,~,~,Cmin,Cmax] = Data.ComputeCurvature();

Ctotal = abs(Cmin)+abs(Cmax); % absolute total curvature

switch(var)
    case 'total'
        filter = Ctotal;
    case 'gauss'
        filter = Cgauss;
    case 'product'
        filter = abs(Ctotal.*Cgauss);
end

tRemeshS = tic;
[vertexV,facesV] = FeatureRemesh(vertex1,faces1,remeshN,filter,currentFolder);
tRemesh = toc(tRemeshS);

[vertexV,facesV] = MeshEnsureManifold(vertexV,facesV);
[vertexV,facesV]= MeshProcess(vertexV,facesV);


%% Step3: Geodesic distance computation
tGeodesicS = tic;
DS = GeodesicDistance(vertexV,facesV);
tGeodesic = toc(tGeodesicS);

%% Step4: Clustering-based segmentation
tFinddcS = tic;
[rho,delta,dc,p] = FindBestDesicionValue(DS);
tFinddc = toc(tFinddcS);

[C_ind,N] = ClusterCenter(rho,delta);

%% Step5: Segment reconstruction 
% position of cluster center on the original mesh
vertexC = vertexV(C_ind,:);
[~,IC] = pdist2(vertex1,vertexC,'euclidean','Smallest',1);

% project the clustering result to the orignal(designed) shape
[label1,~] = GenerateVoronoiDiagram(vertex1,faces1,IC,para.currentFolder);  

% Reconstruct the segment with boundary cleanned 
lenm = MaxLength(vertex1,faces1);
[V_seg,F_seg] = SegReconstruction(label1,vertex1,N,'boundary',lenm);  

T = [tRemesh/60,tGeodesic/60,tFinddc/60];

%% save the results

M.Whole.V = vertex1;
M.Whole.F = faces1;
% M.Whole.lmk_all = lmk_all; % landmark index in the whole shape 
M.Whole.label = label1;
M.Whole.Center = IC;

M.Remesh.V = vertexV;
M.Remesh.F = vertexF;
M.Remesh.Center = C_ind;

M.Seg.V_seg = V_seg;
M.Seg.F_seg = F_seg;
% M.Seg.lmk = lmk; % landmark index on each segment 
M.Seg.Center = CindS; % landmark index on each segment

M.Decision.rho = rho;
M.Decision.delta = delta;
M.Decision.p = p;
M.Decision.DS = DS;
M.Decision.dc = dc;

M.time.remesh = tRemesh/60;
M.time.geodesic = tGeodesic/60;
M.time.decision = tFinddc/60;
end