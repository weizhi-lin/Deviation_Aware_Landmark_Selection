function AGD = AverageGeosdesic(vertex,faces)
% compute the average geodesic distance on every vertex

N = size(vertex,1);
area = [];
D = {};
AGD = [];
[vertex,faces] = MeshEnsureManifold(vertex,faces);
M = Mesh('VF',vertex',faces');
area = meshSurfaceArea(M.V',M.F');
M.Normalize();
[~,~,flip] = M.ComputeNormal();
if flip
    M.F = M.F([1 3 2],:);
end
M.Aux.WKS = M.ComputeWKS([]);
vertex = M.V';
faces = M.F';
for i = 1:N
    D{i} = GeodesicDistanceOneSource(vertex,faces,i);
    AGD(i) = sum(D{i})/area;
end

end