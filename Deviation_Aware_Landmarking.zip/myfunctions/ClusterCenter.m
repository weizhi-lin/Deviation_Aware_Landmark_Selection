function [C_ind,N] = ClusterCenter(rho,delta)
rho=mapminmax(rho', 0, 1)';
delta=mapminmax(delta', 0, 1)';
X = [rho,delta];
d = rho.*delta;
[B,index] = sortrows([X,d],3,'descend');
dis = [];
Cor = [];
for i = 2:100
    dis(i-1) = abs(norm(cov(B(1:i,1:2)))-norm(cov(B(1:i-1,1:2))));   % applied
    Cor(i-1)=norm(corr(B(1:i,1:2)));
%     dis2(i-1) = abs(var(B(1:i+1,1))-var(B(1:i,1))); 
    Var(i-1) = norm(cov(B(1:i,1:2)));
%     V(i-1)=var(B(1:i,3));
    if i>3
        E = abs(diff(dis));
        EC = abs(diff(Cor));
        if  B(i,2) < 0.05
            N = i-1;%abs(d(i)-d(i-1))<0.001 %abs(B(i+1,2)-B(i,2))<0.01  %B(i,1) < mean(rho)||
            break
        end
%         if EC(end) < 0.01 && Var(end) < 0.1 %&&E(end) < 0.001
%             break
%         end
        if E(end) < 0.001 && Var(end) < 0.1 
            N = i;
            break
        end
    end
end

% for i = 2:100
% %     dis(i-1) = abs(norm(cov(B(1:i,1:2)))-norm(cov(B(1:i-1,1:2))));   
% %     dis2(i-1) = abs(var(B(1:i+1,1))-var(B(1:i,1))); 
% %     Var(i-1) = norm(cov(B(1:i,1:2)));
% %     V(i-1)=var(B(1:i,2));
%     Cor(i-1)=norm(corr(B(1:i,1:2)));
%     if i>4
%         E = abs(diff(Cor));
%         if B(i,2) < 0.05 %|| abs(d(i)-d(i-1))<0.0001 %abs(B(i+1,2)-B(i,2))<0.01  %
%             break
%         end
%         if E(end) < 0.01 && norm(cov(B(1:i,1:2))) < 0.1 %&&E(end) < 0.001
%             break
%         end
%     end
% end

% N = i;
C_ind = index(1:N);

end

% for i = 2:100
%     dis(i-1) = abs(norm(cov(B(1:i,1:2)))-norm(cov(B(1:i-1,1:2))));   
% %     dis2(i-1) = abs(var(B(1:i+1,1))-var(B(1:i,1))); 
% %     Var(i-1) = norm(cov(B(1:i,1:2)));
% %     V(i-1)=var(B(1:i,3));
%     if i>3
%         E = abs(diff(dis));
%         if B(i,1) < mean(rho)|| abs(d(i)-d(i-1))<0.001 %abs(B(i+1,2)-B(i,2))<0.01  %
%             break
%         end
%         if E(end) < 0.001 && norm(cov(B(1:i+2,1:2))) < 0.1 
%             break
%         end
%     end
% end

% 
% figure()
% scatter(rho,delta);hold on
% scatter(rho(C_ind),delta(C_ind),'r')