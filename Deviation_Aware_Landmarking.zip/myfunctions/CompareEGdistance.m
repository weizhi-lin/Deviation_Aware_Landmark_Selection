function [vertex1,faces1,vertexV,facesV] = CompareEGdistance(data_folder,data_file1,para)
currentFolder = para.currentFolder;

Mesh_Design = Mesh('off',fullfile(data_folder,data_file1));
vertex1 = Mesh_Design.V';
faces1 = Mesh_Design.F';
[vertex1,faces1] = trimMesh(vertex1,faces1);

Nvertex = size(vertex1,1);
if Nvertex < 1e+5
    remeshN = 3000;
else
    remeshN = Nvertex *0.03;
    remeshN = min(remeshN,5000);
end

tStart = tic;
%% Step2: Feature sensitive remeshing
[~,~,Cmin,Cmax,~,~,~] = compute_curvature(vertex1,faces1);
filter = abs(Cmin)+abs(Cmax); % absolute total curvature

tRemeshS = tic;
[vertexV,facesV] = FeatureRemesh(vertex1,faces1,remeshN,filter,currentFolder);
tRemesh = toc(tRemeshS);
disp(['Time of remeshing is ',num2str(tRemesh/60),'min']) 

[vertexV,facesV]= MeshProcess(vertexV,facesV);

%% Step3: Geodesic distance computation
tGeodesicS = tic;
DS = GeodesicDistance(vertexV,facesV);
tGeodesic = toc(tGeodesicS);

%% Step4: Clustering-based segmentation
tFinddcS = tic;
[rho,delta,~,p1] = FindBestDesicionValue(DS);
tFinddc = toc(tFinddcS);

[C_ind,N] = ClusterCenter(rho,delta);

disp(['Number of segments is ',num2str(N)]) 
% assign vertex to each cluster 
label = AssignCluster(C_ind, DS);

%% Step5: Segment projection and reconstruction 

% position of cluster center on the original mesh
vertexC = vertexV(C_ind,:);
[~,IC] = pdist2(vertex1,vertexC,'euclidean','Smallest',1);

% project the clustering result to the orignal(designed) shape
label1 = ProjectClustering(vertexV, vertex1, label);

%% Visualization 
figure()
subplot(1,3,3)
scatter(rho,delta);hold on
scatter(rho(C_ind),delta(C_ind),'r');
title([data_file1, ' Decision Graph: number of segments',num2str(N)]);

% show the positions of cluster center on the remeshed mesh 
subplot(1,3,1)
options.face_vertex_color = label;
plot_mesh(vertexV,facesV,options);shading faceted;
colormap jet(256);
hold on;
h = plot3(vertexV(C_ind,1), vertexV(C_ind,2), vertexV(C_ind,3), 'r.');
set(h, 'MarkerSize', 25);
title([data_file1,'number of segments',num2str(N),'; Size of remesh:',num2str(size(vertexV,1))]);

% clustering result on the original shape
subplot(1,3,2)
options.face_vertex_color = label1;
plot_mesh(vertex1,faces1,options);%shading faceted;
colormap jet(256);
hold on;
h = plot3(vertex1(IC,1), vertex1(IC,2), vertex1(IC,3), 'r.');
set(h, 'MarkerSize', 25);
title([data_file1,'number of segments',num2str(N)]);
sgtitle('Geodesic distance');

%% Euclidean distance 
D = pdist(vertexV);
DS_E = squareform(D);

%% Step4: Clustering-based segmentation
tFinddcS = tic;
[rho,delta,~,p2] = FindBestDesicionValue(DS_E);
tFinddc = toc(tFinddcS);

[C_ind,N] = ClusterCenter(rho,delta);

disp(['Number of segments is ',num2str(N)]) 
% assign vertex to each cluster 
label = AssignCluster(C_ind, DS_E);

%% Step5: Segment projection and reconstruction 
% position of cluster center on the original mesh
vertexC = vertexV(C_ind,:);
[~,IC] = pdist2(vertex1,vertexC,'euclidean','Smallest',1);

% project the clustering result to the orignal(designed) shape
label1 = ProjectClustering(vertexV, vertex1, label);

figure()
subplot(1,3,3)
scatter(rho,delta);hold on
scatter(rho(C_ind),delta(C_ind),'r');
title([data_file1, ' Decision Graph: number of segments',num2str(N)]);

% show the positions of cluster center on the remeshed mesh 
subplot(1,3,1)
options.face_vertex_color = label;
plot_mesh(vertexV,facesV,options);shading faceted;
colormap jet(256);
hold on;
h = plot3(vertexV(C_ind,1), vertexV(C_ind,2), vertexV(C_ind,3), 'r.');
set(h, 'MarkerSize', 25);
title([data_file1,'number of segments',num2str(N),'; Size of remesh:',num2str(size(vertexV,1))]);

% clustering result on the original shape
subplot(1,3,2)
options.face_vertex_color = label1;
plot_mesh(vertex1,faces1,options);%shading faceted;
colormap jet(256);
hold on;
h = plot3(vertex1(IC,1), vertex1(IC,2), vertex1(IC,3), 'r.');
set(h, 'MarkerSize', 25);
title([data_file1,'number of segments',num2str(N)]);

sgtitle('Euclidean distance');
end