function x = reverse(x)

% flip a vector

x = x(end:-1:1);