classdef SolverProjectorModeEnum<handle
    
   enumeration
        AltProj;
        Tangent;
        MultiTangent;
   end
    
end

